 package com.udbac.versionpublish.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.udbac.versionpublish.entity.User;
import com.udbac.versionpublish.service.UserService;
import com.udbac.versionpublish.util.JwtUtil;
import com.udbac.versionpublish.util.ResponseData;

/**
 * @author dundun.wang
 * @date 2019/05/27
 */
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;
    
    @RequestMapping("/login")
    public ResponseData login(@RequestBody User user) {
    	ResponseData response = userService.getUserByUsername(user);
    	return response;
    }
    @RequestMapping("/getToken")
    public ResponseData getToken() {
    	// 获取token
    	String token = JwtUtil.createJWT("wangdundun");
    	ResponseData res = new ResponseData();
    	res.setObject("第三方ddf1114");
    	res.setMessage("fmds");
    	return res;
    }
    @RequestMapping("/regiter")
    public ResponseData register(@RequestBody User user) {
    	ResponseData response = new ResponseData();
    	return response;
    }
    @RequestMapping("/test")
    public ResponseData test () {
    	return new ResponseData();
    }
}

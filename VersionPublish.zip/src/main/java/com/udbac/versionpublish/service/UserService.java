 package com.udbac.versionpublish.service;

import com.udbac.versionpublish.entity.User;
import com.udbac.versionpublish.util.ResponseData;

/**
 * @author dundun.wang
 * @date 2019/05/27
 */
public interface UserService {
	ResponseData getUserByUsername(User user);
}

package com.udbac.versionpublish.util;

public class ResponseData {
	public static final boolean SUCCESS = true;
	public static final boolean FAILD = false;

	private boolean code;
	private String message;
	private Object object;

	public boolean getCode() {
		return code;
	}
	public void setCode(boolean code) {
		this.code = code;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getObject() {
		return object;
	}
	public void setObject(Object object) {
		this.object = object;
	}

}

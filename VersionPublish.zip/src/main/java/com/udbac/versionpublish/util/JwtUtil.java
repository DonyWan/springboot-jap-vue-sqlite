package com.udbac.versionpublish.util;

import java.security.Key;
import java.util.Date;

import javax.crypto.SecretKey;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

public class JwtUtil {
//	private final static String APP_ID = "app_id";
//	private final static String APP_SECRET = "app_secret";
	private final static long ISSUER = 60 * 60 * 1000;
	/**********************/
	private static final String KEY1 = "somethinghereshouldbelongdsaomfomdsaofmoosdmasmsm";

	/**
	 * 由字符串生成加密key
	 * 
	 * @return
	 */
	private static SecretKey generalKey() {
		SecretKey key = Keys.hmacShaKeyFor(KEY1.getBytes());
		return key;
	}

	// Sample method to construct a JWT
	public static String createJWT(String subject) {
		Key key = generalKey();

		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);
		Date expirationDate = new Date(ISSUER + nowMillis);
		// Let's set the JWT Claims
		String jws = Jwts.builder().setIssuedAt(now).setSubject(subject)
				.setExpiration(expirationDate).signWith(key).compact();

		return jws;
	}
	// Sample method to validate and read the JWT
	public static Claims parseJWT(String jwt) throws JwtException {
		Key key = generalKey();
		Claims claims = Jwts.parser().setSigningKey(key).parseClaimsJws(jwt)
				.getBody();
		// System.out.println("ID: " + claims.getId());
		// System.out.println("Subject: " + claims.getSubject());
		// System.out.println("Issuer: " + claims.getIssuer());
		// System.out.println("Expiration: " + claims.getExpiration());
		return claims;
	}
	public static boolean isTokenExpired(Date expiration) {
		return expiration.before(new Date());
	}
	//
	// /**
	// * 创建jwt
	// *
	// * @param subject
	// * @return
	// * @throws Exception
	// */
	// public static String createJWT1(String subject) {
	// Key key = generalKey();
	// // Key key = getKey();
	// Date now = new Date();
	// Date thirtyMinutes = new Date(
	// System.currentTimeMillis() + 30 * 60 * 1000);
	//
	// String jws = Jwts.builder().setSubject(subject) // 主题
	// .setIssuedAt(now) // 签发时间
	// .setExpiration(thirtyMinutes) // 过期时间
	// .signWith(key).compact();
	//
	// return jws;
	//
	// }
	//
	// /**
	// * 解密jwt
	// *
	// * @param jwt
	// * 密钥
	// * @return 主题
	// * @throws Exception
	// * 如果发生 JwtException，说明该密钥无效
	// */
	// public static String parseJWT1(String jwt) throws JwtException {
	// Key key = generalKey();
	// // Key key = getKey();
	// try {
	// return Jwts.parser().setSigningKey(key).parseClaimsJws(jwt)
	// .getBody().getSubject();
	// } catch (JwtException ex) {
	// ex.printStackTrace();
	// System.out.println("签证失效");
	// return null;
	// }
	// }
}

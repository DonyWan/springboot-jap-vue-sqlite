package com.udbac.versionpublish;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.udbac.versionpublish.entity.User;
import com.udbac.versionpublish.entity.Version;
import com.udbac.versionpublish.repository.VersionRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class VersionPublishApplicationTests {
	
	@Resource
	VersionRepository vr;

	@Test
	public void contextLoads() {
		Version v = new Version();
		v.setId(UUID.randomUUID().toString());
		v.setCreateTime("2019-04-23");
		v.setNotes("版本记录");
		v.setProvince("anhui");
		v.setUpdateTime("2019-04-25");
		v.setUser("wang");
//		v.setVersionDate("2019-04-23");
		v.setVersionNumber("1.2.3");
		vr.save(v);
		List<Version> vrs = vr.findAll();
		for (Version version : vrs) {
			System.out.println(version.getCreateTime());
		}
	}
	@Test
	public void creatUser() {
		User user = new User();
		user.setId(UUID.randomUUID().toString());
		user.setUsername("dundun");
//		user.setPassword();
		try {
			MessageDigest.getInstance("test").getAlgorithm();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
